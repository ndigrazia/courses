# Azure Functions Image Thumbnail 

## Explanation
This demo is part of a course *Azure Functions Masterclass* on [Udemy](https://www.udemy.com/course/azure-functions-masterclass/?referralCode=DB5EC4045241D9C76097![image](https://user-images.githubusercontent.com/41804489/124524513-fd6a6600-ddc0-11eb-835a-a35a23cd6724.png)
)
