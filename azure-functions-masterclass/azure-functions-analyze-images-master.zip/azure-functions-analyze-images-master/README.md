# Azure Functions Image Thumbnail 

## Explanation
This demo is part of a course *Azure Functions Masterclass* on [Udemy](https://www.udemy.com/course/azure-functions-masterclass/?referralCode=DB5EC4045241D9C76097![image](https://user-images.githubusercontent.com/41804489/124524489-d7dd5c80-ddc0-11eb-9df8-464ab36e7753.png)
)
