namespace SignalRTelemetry;

public class TelemetryData  {
    public int Decibels  {get; set;}
}